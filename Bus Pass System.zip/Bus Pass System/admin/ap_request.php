<?php
include "../includes/dbconnection.php";
$idno=$_GET['idno'];
$q="select * from tblreq where idno='$idno'";
$rs=mysqli_query($dbh,$q);
while($r=mysqli_fetch_array($rs)){
$duration=$r['duration'];
$depo_status=$r['depo_status'];
$clg_status=$r['clg_status'];
$pay_status=$r['status'];
}

if($clg_status=='Pending'||$pay_status=='Pending' ){
	 echo "<script>alert('All Status not Approved'); window.location.href = 'view_request.php';</script>";
}
else
{
$passno=rand(100000,999999);
date_default_timezone_set("Asia/Kolkata");
$pcd=date("Y-m-d h:i:s");
$tomorrow = date("Y-m-d", time() + 86400);
$time = strtotime($tomorrow);
$final = date("Y-m-d", strtotime("+".$duration."month", $time));
$sq="select * from tblreq where idno='$idno'";
$res=mysqli_query($dbh,$sq);
while($row=mysqli_fetch_array($res)){
    $source=$row['source'];
    $dest=$row['destination'];
     $cost=$row['cost'];
}
$query="update tblpass set pass_status='Active',PassNumber='$passno',PasscreationDate='$pcd',FromDate='$tomorrow',ToDate='$final',Source='$source',Destination='$dest',Cost='$cost' where IdentityCardno='$idno'";
if(mysqli_query($dbh,$query)){
	$sql="update tblreq set depo_status='Approved' where idno='$idno'";
 if(mysqli_query($dbh,$sql))
 	{
 	 echo "<script>alert('Student Approved'); window.location.href = 'view_request.php';</script>";
 	}
 	else
 	{
 		 echo "<script>alert('Action Failed'); window.location.href = 'view_request.php';</script>";
 	}
}
else{
	echo "<script>alert('Failed to execute'); window.location.href = 'view_request.php';</script>";
}
}
?>