<?php
include "../includes/dbconnection.php";
$idno=$_GET['idno'];
$sql="delete from tblreq where idno='$idno'";
 if(mysqli_query($dbh,$sql))
 	{
 	 echo "<script>alert('Student Request Deleted'); window.location.href = 'view_request.php';</script>";
 	}
 	else
 	{
 		 echo "<script>alert('Action Failed'); window.location.href = 'view_request.php';</script>";
 	}
?>