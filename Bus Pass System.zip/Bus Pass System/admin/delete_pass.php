<?php
include "../includes/dbconnection.php";
$pno=$_GET['pno'];
$sql="update tblpass set pass_status='Deactive' where PassNumber='$pno'";
 if(mysqli_query($dbh,$sql))
 	{
 	 echo "<script>alert('Pass Deactivate'); window.location.href = 'manage_pass.php';</script>";
 	}
 	else
 	{
 		 echo "<script>alert('Action Failed'); window.location.href = 'manage_pass.php';</script>";
 	}
?>