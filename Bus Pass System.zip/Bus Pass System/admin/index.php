<!DOCTYPE html>
<html>

<head>
 
    <title>Bus Pass System | Login Page</title>
    <!-- Core CSS - Include with every page -->
    <link href="assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
   <link href="assets/css/style.css" rel="stylesheet" />
      <link href="assets/css/main-style.css" rel="stylesheet" />

</head>

<body class="body-Login-back">

    <div class="container">
       
        <div class="row">
            <div class="col-md-4 col-md-offset-4 text-center logo-margin ">
              <h3 style="color: white;">Bus Pass System</h3>
                </div>
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">                  
                    <div class="panel-heading">
                        <h3 class="panel-title">Please Sign In</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" method="post" name="login">
                            <fieldset>
                                <div class="form-group">
                                    <label for="login-username">Username</label>
                                     <input type="text" class="form-control"  required="true" name="username">
                                                
                                </div>
                                <div class="form-group">
                                    <label for="login-password">Password</label>
                                    <input type="password" class="form-control" name="password" required="true">
                                                
                                </div>
                                <div class="checkbox">                                

<label style="padding-left: 40px">
    <a href="forgot-password.php">Lost Password?</a></label>
                                </div>

                                <!-- Change this to a button or input when using this as a form -->
                               
                                <input type="submit" value="Login" class="btn btn-lg btn-success btn-block" name="login" >
                            </fieldset>
                        </form>
                        <div>
                    <i class="fa fa-home" style="font-size: 30px" aria-hidden="true"></i>
                    <p><a href="../index.php"> Back Home </a></p>
                </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

     <!-- Core Scripts - Include with every page -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>

</body>
<?php
include "../includes/dbconnection.php";
if(isset($_POST['login'])){
    $username = $_POST['username'];
    $password =md5($_POST['password']);

    
    $sql="SELECT * FROM tbladmin WHERE UserName = '$username' and Password = '$password'";
     $result = mysqli_query($dbh, $sql);
       if (mysqli_num_rows($result) == 1) {
    while($row=mysqli_fetch_array($result)){
                session_start();
                $_SESSION['aname'] = $row['UserName'];
                $_SESSION['aid'] = $row['ID'];
                header("Location: dashboard.php");
       }}
        else
        {   
        ?>  
        <script>alert("login failed");
        </script>
        <?php
         
       }
        }



?>
</html>
