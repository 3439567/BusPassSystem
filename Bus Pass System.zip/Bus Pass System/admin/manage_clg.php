<?php
include('../includes/dbconnection.php');
session_start();
if (!isset($_SESSION['aname'])) {
  header('location:index.php');
  } 
  ?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        body{
    
    background-color:#B3E5FC;

}


.card-1{

  border: none;
    border-radius: 10px;
    width: 100%;
    background-color: #fff;
}


.icons i {
 
  margin-left: 20px;
 
}
a:link {
  text-decoration: none;
}
    </style>
     <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css' rel='stylesheet'>
 <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css' rel='stylesheet'>
 <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
<div class="container mt-5">

            <table class="table table-borderless table-responsive card-1 p-4">
  <thead>
    <tr class="border-bottom">
      
      <th>
          <span class="ml-2">Id</span>
      </th>
      <th>
          <span class="ml-2">College Name</span>
      </th>
      <th>
          <span class="ml-2">Email</span>
      </th>
       <th>
          <span class="ml-2">Contact</span>
      </th>
      <th>
          <span class="ml-4">Action</span>
      </th>
    </tr>
  </thead>
  <tbody>
    <?php

 $sql="select * from tblclg";
    $result=mysqli_query($dbh,$sql);
    while($row=mysqli_fetch_array($result)){
    $idno = $row['id'];
    $cname = $row['name'];
    $email = $row['email'];
    $contact = $row['contact'];

    ?>
    <tr class="border-bottom">
     
       <td>
          <div class="p-2">
              <span class="font-weight-bold"><?php echo $idno;?></span>
          </div>
      </td>
      <td>
          <div class="p-2">
              <span class="font-weight-bold"><?php echo $cname;?></span>
          </div>
      </td>
      <td>
          <div class="p-2 d-flex flex-column">
              <span class="font-weight-bold"><?php echo $email;?></span>
          </div>
      </td>
      <td>
          <div class="p-2">
              <span class="font-weight-bold"><?php echo $contact;?></span>
          </div>
      </td>
      
      <td>
          <div class="p-2">
              <a href="remove_clg.php?idno=<?php echo $idno;?>"><span class="font-weight-bold" style="color:blue;">Remove</a></span>
          </div>
      </td>
    </tr>
    
<?php
}
?>


  </tbody>
</table>
    
         
     </div>
</body>
</html>