<?php
include "../includes/dbconnection.php";
session_start();
if(!isset($_SESSION["aid"])){
 header("location:index.php");
}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel='stylesheet'>
	<script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
<div class="min-h-screen bg-gray-100 py-5">
        <div class='overflow-x-auto w-full'>
            <table class='mx-auto max-w-4xl w-full whitespace-nowrap rounded-lg bg-white divide-y divide-gray-300 overflow-hidden'>
                <thead class="bg-gray-900">
                    <tr class="text-white text-left">
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Pass No </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Student Name </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Image </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Id No </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4"> College Name </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Source </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Destination </th>
                         <th class="font-semibold text-sm uppercase px-6 py-4"> FromDate </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> ToDate </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4">Cost</th>
                        <th class="font-semibold text-sm uppercase px-6 py-4">Action</th>

                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                	<?php
                	
    $sql="select * from tblpass where PassNumber!=''";
    $result=mysqli_query($dbh,$sql);
    while($row=mysqli_fetch_array($result)){
    $pno = $row['PassNumber'];
    $sname = $row['FullName'];
    $mob = $row['ContactNumber'];
    $source = $row['Source'];
    $destination = $row['Destination'];
    $idno = $row['IdentityCardno'];
     $img = $row['ProfileImage'];
     $clg = $row['college'];
     $fd = $row['FromDate'];
     $td = $row['ToDate'];
     $cost = $row['Cost'];

?>
                    <tr>
                        <td class="px-6 py-4">
                            <p class=""> <?php echo $pno;?> </p>
                            <p class="text-gray-500 text-sm font-semibold tracking-wide"> <!--Development --></p>
                        </td>
                        <td class="px-6 py-4">
                            <p class=""> <?php echo $sname;?> </p>
                            <p class="text-gray-500 text-sm font-semibold tracking-wide"> <!--Development --></p>
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex items-center space-x-3">
                                <div class="inline-flex w-10 h-10"> 
                                	<img class='w-10 h-10 object-cover rounded-full' alt='User avatar' src='../student/<?php echo $img;?>' /> 
                                </div>
                            </div>
                        </td>
                            <td class="px-6 py-4">
                            <p class=""> <?php echo $idno;?> </p>
                            <p class="text-gray-500 text-sm font-semibold tracking-wide"> <!--Development --></p>
                        </td>
                        </td>
                        <td class="px-6 py-4">
                            <p class=""> <?php echo $clg;?> </p>
                            <p class="text-gray-500 text-sm font-semibold tracking-wide"> <!--Development --></p>
                        </td>
                       
                         <td class="px-6 py-4 text-center"> <?php echo $source;?></td>
                        <td class="px-6 py-4 text-center"><?php echo $destination;?></td>
                        <td class="px-6 py-4 text-center"><span class="text-white text-sm w-1/3 pb-1 bg-blue-600 font-semibold px-2 rounded-full"><?php echo $fd;?></span></td>
                        <td class="px-6 py-4 text-center"><span class="text-white text-sm w-1/3 pb-1 bg-blue-600 font-semibold px-2 rounded-full"><?php echo $td;?></span></td>
                        <td class="px-6 py-4 text-center"><span class="text-white text-sm w-1/3 pb-1 bg-blue-600 font-semibold px-2 rounded-full"><?php echo $cost;?></span></td>
                        <td class="px-6 py-4 text-center"><span class="text-white text-sm w-1/3 pb-1 bg-blue-600 font-semibold px-2 rounded-full"><a href="delete_pass.php?pno=<?php echo $pno;?>">Delete Pass</a></span></td>
                    </tr>
                    <?php
                    	}
?>
                        
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>