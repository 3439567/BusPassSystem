<?php
include "../includes/dbconnection.php";
session_start();
if (!isset($_SESSION['aname'])) {
  header('location:index.php');
  } 
  ?>
$idno=$_GET['idno'];
$sql="delete from tblclg where id='$idno'";
 if(mysqli_query($dbh,$sql))
 	{
 	 echo "<script>alert('College Removed'); window.location.href = 'manage_clg.php';</script>";
 	}
 	else
 	{
 		 echo "<script>alert('Action Failed'); window.location.href = 'manage_clg.php';</script>";
 	}
?>