<?php
include('../includes/dbconnection.php');
session_start();
if (!isset($_SESSION['aname'])) {
  header('location:student_login.php');
  } 
  ?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        body{
    
    background-color:#B3E5FC;

}


.card-1{

  border: none;
    border-radius: 10px;
    width: 100%;
    background-color: #fff;
}


.icons i {
 
  margin-left: 20px;
 
}
a:link {
  text-decoration: none;
}
    </style>
     <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css' rel='stylesheet'>
 <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css' rel='stylesheet'>
 <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
<div class="container mt-5">

            <table class="table table-borderless table-responsive card-1 p-4">
  <thead>
    <tr class="border-bottom">
      
      <th>
          <span class="ml-2">Student</span>
      </th>
      <th>
          <span class="ml-2">College</span>
      </th>
      <th>
          <span class="ml-2">Source</span>
      </th>
       <th>
          <span class="ml-2">Destination</span>
      </th>
        <th>
          <span class="ml-2">Cost</span>
      </th>
        <th>
          <span class="ml-2">Clg Status</span>
      </th>
      <th>
          <span class="ml-2">Depo Status</span>
      </th>
        <th>
          <span class="ml-2">Payment</span>
      </th>
      <th>
          <span class="ml-4">Action</span>
      </th>
    </tr>
  </thead>
  <tbody>
    <?php

$sql="select * from tblrenew where pay_status='Pending'";
$result=mysqli_query($dbh,$sql);
if (mysqli_num_rows($result) == 1) {
while($row=mysqli_fetch_array($result)){
    $sname=$row['sname'];
    $idno=$row['sid'];
    $cname=$row['cname'];
    $source=$row['source'];
    $dest=$row['destination'];
     $ds=$row['depo_status'];
    $cs=$row['clg_status'];
     $cost=$row['cost'];
    $pay=$row['pay_status'];

$sql1="select * from tblpass where IdentityCardno='$idno'";
$result1=mysqli_query($dbh,$sql1);
while($row=mysqli_fetch_array($result1)){
    $pic=$row['ProfileImage'];

}
    ?>
    <tr class="border-bottom">
     
      <td>
           <div class="p-2 d-flex flex-row align-items-center mb-2">
              <img src="../student/<?php echo $pic;?>" width="40" class="rounded-circle">
              <div class="d-flex flex-column ml-2">
                  <span class="d-block font-weight-bold"><?php echo $sname;?></span>
                  <small class="text-muted"><?php echo $idno;?></small>
              </div>
          </div>

      </td>
      <td>
          <div class="p-2">
              <span class="font-weight-bold"><?php echo $cname;?></span>
          </div>
      </td>
      <td>
          <div class="p-2 d-flex flex-column">
              <span class="font-weight-bold"><?php echo $source;?></span>
          </div>
      </td>
      <td>
          <div class="p-2">
              <span class="font-weight-bold"><?php echo $dest;?></span>
          </div>
      </td>
      <td>
          <div class="p-2">
              <span class="font-weight-bold"><?php echo $cost;?></span>
          </div>
      </td>
      <td>
          <div class="p-2">
              <span class="font-weight-bold"><?php echo $cs;?></span>
          </div>
      </td>
      <td>
          <div class="p-2">
              <span class="font-weight-bold"><?php echo $ds;?></span>
          </div>
      </td>
      <td>
          <div class="p-2">
              <span class="font-weight-bold"><?php echo $pay;?></span>
          </div>
      </td>
      <td>
          <div class="p-2">
              <a href="ap_request.php?idno=<?php echo $idno;?>"><span class="font-weight-bold" style="color:blue;">Approve</a></span>
              <a href="dc_request.php?idno=<?php echo $idno;?>"><span class="font-weight-bold" style="color:red;">Decline</a></span>
          </div>
      </td>
    </tr>
    
<?php
}}
else{
  ?>
  <tr class="border-bottom">
    <td>
  No request is queue
</td>
</tr>
<?php
}
?>


  </tbody>
</table>
    
         
     </div>
</body>
</html>