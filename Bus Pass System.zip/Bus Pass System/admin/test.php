<?php
include "../includes/dbconnection.php";
 $sql="SELECT * FROM tblpass";
     $result = mysqli_query($dbh, $sql);
    while($row=mysqli_fetch_array($result)){
      $fname=$row['FullName'];
      $idno=$row['IdentityCardno'];
      $cname=$row['college'];
      $source=$row['Source'];
      $dest=$row['Destination'];
      echo $fname;
}

?>
