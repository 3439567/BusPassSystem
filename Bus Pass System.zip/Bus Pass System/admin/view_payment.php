<?php
include "../includes/dbconnection.php";
session_start();
if(!isset($_SESSION["aid"])){
 header("location:index.php");
}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel='stylesheet'>
	<script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
<div class="min-h-screen bg-gray-100 py-5">
        <div class='overflow-x-auto w-full'>
            <table class='mx-auto max-w-4xl w-full whitespace-nowrap rounded-lg bg-white divide-y divide-gray-300 overflow-hidden'>
                <thead class="bg-gray-900">
                    <tr class="text-white text-left">
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Transaction No </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Student Name </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Id No </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4"> College Name </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Payment Date </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Amount </th>
                       
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                	<?php
                	
    $sql="select * from tblreq where status='Paid' order by trans_date desc";
    $result=mysqli_query($dbh,$sql);
    while($row=mysqli_fetch_array($result)){
    $sname = $row['sname'];
    $trans_id = $row['trans_id'];
    $trans_date = $row['trans_date'];
    $idno = $row['idno'];
     $clg = $row['cname'];
     $cost = $row['cost'];

?>
                    <tr>
                        <td class="px-6 py-4">
                            <p class=""> <?php echo $trans_id;?> </p>
                          
                        </td>
                        <td class="px-6 py-4">
                            <p class=""> <?php echo $sname;?> </p>
                        
                        </td>
                            <td class="px-6 py-4">
                            <p class=""> <?php echo $idno;?> </p>
                         
                        </td>
                        </td>
                        <td class="px-6 py-4">
                            <p class=""> <?php echo $clg;?> </p>
                           
                        </td>
                       
                         <td class="px-6 py-4 text-center"> <?php echo  $trans_date?></td>
                        <td class="px-6 py-4 text-center"><?php echo $cost;?></td>
                    
                      
                       
                    </tr>
                    <?php
                    	}
?>
                        
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>