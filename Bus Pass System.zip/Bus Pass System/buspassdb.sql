-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2023 at 03:24 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `buspassdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(10) NOT NULL,
  `AdminName` varchar(120) DEFAULT NULL,
  `UserName` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `Password` varchar(200) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(1, 'Admin', 'admin', 1234567891, 'adminuser@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2020-04-14 06:44:27');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `ID` int(10) NOT NULL,
  `CategoryName` varchar(200) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`ID`, `CategoryName`, `CreationDate`) VALUES
(8, 'AC Bus', '2021-07-04 14:27:53'),
(9, 'Non AC Bus', '2021-07-04 14:28:32'),
(10, 'Volvo Bus', '2021-07-04 14:28:47'),
(11, 'Delux Bus', '2021-07-04 14:29:01');

-- --------------------------------------------------------

--
-- Table structure for table `tblclg`
--

CREATE TABLE `tblclg` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `contact` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblclg`
--

INSERT INTO `tblclg` (`id`, `name`, `email`, `password`, `contact`) VALUES
(1, 'mitm', 'clg@gmail.com', 'c123', 2147483647),
(2, 'gpm', 'gpm@gmail.com', 'gpm123', 987654321);

-- --------------------------------------------------------

--
-- Table structure for table `tbljourney`
--

CREATE TABLE `tbljourney` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `route` varchar(500) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbljourney`
--

INSERT INTO `tbljourney` (`id`, `name`, `route`, `date`) VALUES
(88888, 'demo name', 'Kankavli to Kasal', '2023-02-12'),
(88888, 'demo name', 'Kasal to Kankavli', '2023-02-12');

-- --------------------------------------------------------

--
-- Table structure for table `tblpass`
--

CREATE TABLE `tblpass` (
  `ID` int(10) NOT NULL,
  `PassNumber` varchar(200) DEFAULT NULL,
  `FullName` varchar(200) DEFAULT NULL,
  `ProfileImage` varchar(200) DEFAULT NULL,
  `ContactNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `IdentityType` varchar(200) DEFAULT NULL,
  `IdentityCardno` varchar(200) DEFAULT NULL,
  `college` varchar(50) NOT NULL,
  `Category` varchar(100) DEFAULT NULL,
  `Source` varchar(200) DEFAULT NULL,
  `Destination` varchar(200) DEFAULT NULL,
  `FromDate` date DEFAULT NULL,
  `ToDate` date DEFAULT NULL,
  `Cost` decimal(10,0) DEFAULT NULL,
  `PasscreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `password` varchar(20) NOT NULL,
  `pass_status` varchar(10) NOT NULL DEFAULT 'Deactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblpass`
--

INSERT INTO `tblpass` (`ID`, `PassNumber`, `FullName`, `ProfileImage`, `ContactNumber`, `Email`, `IdentityType`, `IdentityCardno`, `college`, `Category`, `Source`, `Destination`, `FromDate`, `ToDate`, `Cost`, `PasscreationDate`, `password`, `pass_status`) VALUES
(7, '999999', 'Sudesh Jamsandekar', 'upload/sudesh.png', 2222222222, 'abc@gmail.com', NULL, '1234', 'mitm', NULL, 'Kankavli', 'Sukalwad', '2023-01-18', '2023-02-18', '200', '2023-01-17 13:47:33', 's123', 'Active'),
(10, '88888', 'demo name', 'upload/in.png', 1234567890, 'demo@gmail.com', NULL, '4321', 'gpm', NULL, 'Kankavli', 'Kasal', '2023-02-12', '2023-03-12', '380', '2023-02-11 09:11:57', 'd123', 'Active'),
(11, '158195', 'Vishal Kamble', 'upload/para.png', 8007143909, 'v@gmail.com', NULL, '8765', 'gpm', NULL, 'Katta', 'Malvan', '2023-04-04', '2023-05-04', '680', '2023-04-03 01:51:50', 'v123', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tblpayment`
--

CREATE TABLE `tblpayment` (
  `pay_id` varchar(30) NOT NULL,
  `stu_id` int(10) NOT NULL,
  `pay_name` varchar(50) NOT NULL,
  `amount` int(5) NOT NULL,
  `date_of_pay` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpayment`
--

INSERT INTO `tblpayment` (`pay_id`, `stu_id`, `pay_name`, `amount`, `date_of_pay`) VALUES
('pay_LS6HYUUixNMzh8', 4321, 'demo name', 380, '2023-03-16'),
('pay_LVifdBbdxLbghD', 4321, 'demo name', 380, '2023-03-25'),
('pay_LZKnOnNSIyHAmN', 8765, 'Vishal Kamble', 680, '2023-04-03'),
('pay_LZKwlR8J4d2kna', 8765, 'Vishal Kamble', 680, '2023-04-03');

-- --------------------------------------------------------

--
-- Table structure for table `tblrenew`
--

CREATE TABLE `tblrenew` (
  `id` int(5) NOT NULL,
  `sid` varchar(20) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `passid` int(10) NOT NULL,
  `source` varchar(30) NOT NULL,
  `destination` varchar(30) NOT NULL,
  `duration` int(5) NOT NULL,
  `cost` varchar(10) NOT NULL,
  `sname` varchar(30) NOT NULL,
  `depo_status` varchar(10) NOT NULL DEFAULT 'Pending',
  `clg_status` varchar(10) NOT NULL DEFAULT 'Pending',
  `pay_status` varchar(10) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblreq`
--

CREATE TABLE `tblreq` (
  `r_id` int(11) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `idno` varchar(20) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `source` varchar(20) NOT NULL,
  `destination` varchar(20) NOT NULL,
  `depo_status` varchar(20) NOT NULL DEFAULT 'Pending',
  `clg_status` varchar(20) NOT NULL DEFAULT 'Pending',
  `cost` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'Pending',
  `duration` int(5) NOT NULL,
  `trans_id` varchar(20) NOT NULL,
  `trans_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblreq`
--

INSERT INTO `tblreq` (`r_id`, `sname`, `idno`, `cname`, `source`, `destination`, `depo_status`, `clg_status`, `cost`, `status`, `duration`, `trans_id`, `trans_date`) VALUES
(1, 'Sudesh Jamsandekar', '1234', 'mitm', 'Kankavli', 'Sukalwad', 'Approved', 'Approved', '200', 'Paid', 1, 'Trans_12234', '2023-01-22'),
(8, 'demo name', '4321', 'gpm', 'Kankavli', 'Kasal', 'Approved', 'Approved', '380', 'Paid', 1, 'pay_LVifdBbdxLbghD', '2023-03-25'),
(9, 'Vishal Kamble', '8765', 'gpm', 'Katta', 'Malvan', 'Approved', 'Approved', '680', 'Paid', 1, 'pay_LZKwlR8J4d2kna', '2023-04-03');

-- --------------------------------------------------------

--
-- Table structure for table `tblroute`
--

CREATE TABLE `tblroute` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `distance` varchar(5) NOT NULL,
  `ticket` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblroute`
--

INSERT INTO `tblroute` (`id`, `name`, `distance`, `ticket`) VALUES
(1, 'Kankavli', '0', '0'),
(2, 'Vagde', '3', '10'),
(3, 'Osargaon', '9', '15'),
(4, 'Kasal', '12', '20'),
(5, 'Ranbambuli', '18', '25'),
(6, 'Sukalwad', '21', '30'),
(7, 'Kusarave', '24', '35'),
(8, 'Katta', '26', '40'),
(9, 'Kunkavle', '30', '45'),
(10, 'Salel', '33', '50'),
(11, 'Chauke', '36', '55'),
(12, 'Nagarbhat', '39', '60'),
(13, 'Anandvhal', '42', '65'),
(14, 'Kumbharmat', '44', '70'),
(15, 'Malvan', '46', '75');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblclg`
--
ALTER TABLE `tblclg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpayment`
--
ALTER TABLE `tblpayment`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `tblrenew`
--
ALTER TABLE `tblrenew`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblreq`
--
ALTER TABLE `tblreq`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `tblroute`
--
ALTER TABLE `tblroute`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblclg`
--
ALTER TABLE `tblclg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblrenew`
--
ALTER TABLE `tblrenew`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblreq`
--
ALTER TABLE `tblreq`
  MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tblroute`
--
ALTER TABLE `tblroute`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
