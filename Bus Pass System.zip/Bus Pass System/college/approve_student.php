<?php
include "../includes/dbconnection.php";
$idno=$_GET['idno'];
$cname=$_GET['cname'];
$sql="update tblreq set clg_status='Approved' where idno='$idno' and cname='$cname'";
 if(mysqli_query($dbh,$sql))
 	{
 	 echo "<script>alert('Student Approved'); window.location.href = 'home.php';</script>";
 	}
 	else
 	{
 		 echo "<script>alert('Student Declined'); window.location.href = 'view_request.php';</script>";
 	}
?>