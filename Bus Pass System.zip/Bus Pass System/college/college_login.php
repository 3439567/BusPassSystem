<?php
include "../includes/dbconnection.php";
if(isset($_POST['submit'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    
    $sql="SELECT * FROM tblclg WHERE email = '$email' and password = '$password'";
     $result = mysqli_query($dbh, $sql);
       if (mysqli_num_rows($result) == 1) {
    while($row=mysqli_fetch_array($result)){
                session_start();
                $_SESSION['name'] = $row['name'];
                $_SESSION['id'] = $row['id'];
                header("Location: home.php");
       }}
        else
        {   
        ?>  
        <script>alert("login failed");
        </script>
        <?php
         
       }
        }



?>
<html>
<head>
    <title></title>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
    />
    <link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
    />
    <style type="text/css">
@import url(https://fonts.googleapis.com/css?family=Calibri:400,300,700);

body {

    font-family: 'Calibri', sans-serif !important;
    font-size: 14px;
}
a{
    text-decoration: none;
}
.card {
    margin: auto;
    box-shadow: 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    width: 450px;
}

.alert {
    padding: .5rem .5rem !important;
}

@media(max-width:768px) {
    .card {
        width: 90% !important;
    }


}

.upper {
    padding: 6vh 6vh 3vh 6vh;
}

.lower {
    padding: 3vh 0 3vh;
    text-align: center;
}

.heading {
    display: flex;
    align-items: center;
    vertical-align: middle;
}

.heading p {
    margin-bottom: 0;
}

input {
    border: 1px solid rgba(0, 0, 0, 0.137);
    padding: 0.75rem;
    outline: none;
    width: 100%;
    min-width: unset;
    background: rgba(151, 151, 151, 0.212) !important;
}
.eye{
    background: rgba(151, 151, 151, 0.212) !important;
    padding: 1rem;

}
.row>*{
    padding-right: 0 !important;
    padding-left: 0 !important;
   
}
.form-element {
    margin: 3vh 0;
}

form .col-3,
.col-9,
.col-1,
.col--11 {
    padding: 0;
    width: min-content;
}

form .col-11 {
    padding-left: 10px;
}

form .col-1 {
    display: flex;
    align-items: center;
    color: red;
    font-size: 3vh;
    justify-content: center;
}

#code {
    text-align: center;
}

form .row {
    margin: 0;
}

hr {
    margin: 0;
    border-top: 2px solid rgba(0, 0, 0, .1);
}

#input-header {
    color: grey;
}

.invalid {
    color: grey;
    line-height: 1.2;
}

.btn {
    width: 50%;

    color: white;
    padding: 1.5vh 0;
}

.btn:focus {
    box-shadow: none;
    outline: none;
    box-shadow: none;
    color: white;
    -webkit-box-shadow: none;
    -webkit-user-select: none;
    transition: none;
}

.btn:hover {
    color: white;
}

input:focus::-webkit-input-placeholder {
    color: transparent;
}

input:focus:-moz-placeholder {
    color: transparent;
}

/* FF 4-18 */
input:focus::-moz-placeholder {
    color: transparent;
}

/* FF 19+ */
input:focus:-ms-input-placeholder {
    color: transparent;
}

input{
    border: none;
}
/* IE 10+ */
    </style>
</head>
<body>
<div class="Container ">


<div class="card mt-5" style="background-color: #fff !important; border:solid 0px !important;">
    <div class="upper">
        <div class="row">
            <div class="col-8 heading">
                <h4><b>College Login</b></h4>
            </div>

        </div>
        <form id="formL" method="post">

            <div id="alert" class="mt-1" role="alert">

            </div>
            <div class="form-element">
                <span id="input-header">E-mail*</span>
                <input type="email" id="order_id" name="email"
                                                        placeholder="email@gmail.com">
            </div>
            <div class="form-element ">
                <span id="input-header">Password</span>
                <div class="row p-0">
                    <div class="d-flex align-items-center">


                        <input type="password" name="password" id="phone"
                                                                placeholder="pass*****">
                        <i class="fas fa-eye-slash eye"></i>
                    </div>

                </div>
                    <a href="#" class="text-info">Forgot Password?</a>
            </div>
            <div class="form-element">
                <div class="row invalid">
                   
                    <div class="col-11">
                        <h6 class="text-secondary mb-3 text-center">
                            <p class="mb-0">Don't have account</p><a href="register.php" class="text-info">Create
                                an Acount </a>
                              
                    </div>
                </div>
            </div>
            
            <div class="lower">
                <button class="btn btn-warning" type="submit" id="loader" name="submit">Log In</button>
            </div>

        </form>

    </div>


</div>

</div>
<script>
    // declaration des variables
let eye = document.querySelector('.eye')
let password = document.getElementById('phone')

/**
 * cette class contient l'ensemble des actions a effectuer sur cette page
 */
class action {
    toglePassWord(tag) {
        let ClassName = tag.classList.contains('fa-eye-slash')
        if (ClassName == true) {
            tag.classList.replace("fa-eye-slash", "fa-eye")
            password.setAttribute('type', "text")
        } else {
            tag.classList.replace("fa-eye", "fa-eye-slash")
            password.setAttribute('type', "password")
        }
    }
}

// appel de la classe action
let make = new action()
eye.addEventListener('click', function (e) {
    make.toglePassWord(eye)

})
</script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
