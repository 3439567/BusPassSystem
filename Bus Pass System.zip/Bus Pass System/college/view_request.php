<?php
include "../includes/dbconnection.php";
session_start();
if(!isset($_SESSION["id"])){
 header("location:college_login.php");
}
else{
  $id=$_SESSION["id"];
  $name=$_SESSION["name"];
}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel='stylesheet'>
	<script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
<div class="min-h-screen bg-gray-100 py-5">
        <div class='overflow-x-auto w-full'>
            <table class='mx-auto max-w-4xl w-full whitespace-nowrap rounded-lg bg-white divide-y divide-gray-300 overflow-hidden'>
                <thead class="bg-gray-900">
                    <tr class="text-white text-left">
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Student Name </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Id No </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4"> College Name </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Source </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4"> Destination </th>
                         <th class="font-semibold text-sm uppercase px-6 py-4"> Status </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4 text-center"> Action </th>
                        <th class="font-semibold text-sm uppercase px-6 py-4"> </th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                	<?php
                	
   $sql="select * from tblreq where cname='$name'";
    $result=mysqli_query($dbh,$sql);
    while($row=mysqli_fetch_array($result)){
    $sname = $row['sname'];
    $idno = $row['idno'];
    $cname = $row['cname'];
    $source = $row['source'];
    $destination = $row['destination'];
    $status = $row['clg_status'];
$sql1="select * from tblpass where IdentityCardno='$idno'";
    $result1=mysqli_query($dbh,$sql1);
    while($row1=mysqli_fetch_array($result1)){
 $img = $row1['ProfileImage'];
}
?>
                    <tr>
                        <td class="px-6 py-4">
                            <div class="flex items-center space-x-3">
                                <div class="inline-flex w-10 h-10"> 
                                	<img class='w-10 h-10 object-cover rounded-full' alt='User avatar' src='../student/<?php echo $img;?>' /> 
                                </div>
                                <div>
                                    <p> <?php echo $sname;?> </p>
                                    <p class="text-gray-500 text-sm font-semibold tracking-wide"> <!--mirarodeo23@mail.com--> </p>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <p class=""> <?php echo $idno;?> </p>
                            <p class="text-gray-500 text-sm font-semibold tracking-wide"> <!--Development --></p>
                        </td>
                       
                        <td class="px-6 py-4 text-center">  <?php echo $cname;?></td>
                         <td class="px-6 py-4 text-center"> <?php echo $source;?></td>
                        <td class="px-6 py-4 text-center"><?php echo $destination;?></td>
                        <td class="px-6 py-4 text-center"><span class="text-white text-sm w-1/3 pb-1 bg-blue-600 font-semibold px-2 rounded-full"><?php echo $status;?></span></td>
                         <td class="px-6 py-4 text-center"> <span class="text-white text-sm w-1/3 pb-1 bg-green-600 font-semibold px-2 rounded-full"><a href="approve_student.php?idno=<?php echo $idno;?>&cname=<?php echo $cname;?>"> Approve</a></span>
                         <span class="text-white text-sm w-1/3 pb-1 bg-red-600 font-semibold px-2 rounded-full"> 
                         	<a href="decline_student.php?idno=<?php echo $idno;?>&cname=<?php echo $cname;?>">Decline</a></span>
                          </td>
                    </tr>
                    <?php
                    	}
?>
                        
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>