
	<div class="copy-right"> 
		<div class="container">
			<p>© 2023 Bus Pass System</p>
		</div> 
	</div> 
	<!-- //footer -->   
	