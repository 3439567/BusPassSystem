<?php
include('includes/dbconnection.php');
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Bus Pass System || Home Page</title>

<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style.css" type="text/css" rel="stylesheet" media="all"> 
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" /> 
<link href="css/font-awesome.css" rel="stylesheet">		   
<link href="//fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
<style type="text/css">
	.agileits-banner { 
    background:url(images/bus.jpg)no-repeat center 0px; 
	-webkit-background-size:cover;
    -moz-background-size:cover;
  	-o-background-size:cover;  
  	-ms-background-size:cover;  
	background-size:cover;  
	position: relative; 
}
</style>
</head>
<body>  
	
	<div class="agileits-banner">
		<div class="bnr-agileinfo"> 
			<?php include_once('includes/header.php');?>	
			<div class="banner-text agileinfo"> 
			</div>
		</div>
	</div>
	
	<?php include_once('includes/footer.php');?>   
	<script src="js/jquery-2.2.3.min.js"></script> 
    <script src="js/bootstrap.js"></script>
</body>
</html>