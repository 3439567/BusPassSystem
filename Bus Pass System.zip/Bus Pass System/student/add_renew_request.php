<?php
 include '../includes/dbconnection.php';

 if(isset($_POST['submit'])){
	$name = $_POST['name'];
	$idno = $_POST['idno'];
	$cname= $_POST['cname'];
	$source = $_POST['source'];
	$dest = $_POST['dest'];
	$cost= $_POST['fare'];
	$duration=$_POST['duration'];
	
$sql="SELECT * FROM tblrenew WHERE sid='$idno' and cname='$cname'";
      $result = mysqli_query($dbh, $sql);
       if (mysqli_num_rows($result) > 0) {
      echo "<script>alert('Request already Added'); window.location.href = student_renew.php';</script>";
}
else{



	$sql="insert into tblreq (sname,sid,cname,source,destination,duration,cost) values 
	('$name','$idno','$cname','$source','$dest','$duration','$cost')";
	
	if(mysqli_query($dbh,$sql)){
		 echo "<script>alert('Request Added'); window.location.href = 'student_renew.php';</script>";
	
	}
	else{
		 echo "<script>alert('Request Failed'); window.location.href = 'student_renew.php';</script>";
	}
	}
}

?>