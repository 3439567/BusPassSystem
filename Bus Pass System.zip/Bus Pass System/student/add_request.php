<?php
 include '../includes/dbconnection.php';

 if(isset($_POST['submit'])){
	$name = $_POST['name'];
	$idno = $_POST['idno'];
	$cname= $_POST['cname'];
	$source = $_POST['source'];
	$dest = $_POST['dest'];
	$cost= $_POST['fare'];
	$duration=$_POST['duration'];
	$src = preg_replace('/[^a-zA-Z]/', '', $source);
	$dst = preg_replace('/[^a-zA-Z]/', '', $dest);

$sql="SELECT * FROM tblreq WHERE idno='$idno' and cname='$cname'";
      $result = mysqli_query($dbh, $sql);
       if (mysqli_num_rows($result) > 0) {
      echo "<script>alert('Request already Added'); window.location.href = 'apply_pass.php';</script>";
}
else{

	$sql="insert into tblreq (sname,idno,cname,source,destination,duration,cost) values 
	('$name','$idno','$cname','$src','$dst','$duration','$cost')";
	
	if(mysqli_query($dbh,$sql)){
		 echo "<script>alert('Request Added'); window.location.href = 'apply_pass.php';</script>";
	
	}
	else{
		 echo "<script>alert('Request Failed'); window.location.href = 'apply_pass.php';</script>";
	}}
	
}

?>