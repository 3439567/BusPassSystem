<?php
$dest =$_POST['dest']; 
$source=$_POST['source']; 
$query="select * from tblroute where name='$s'";
$result=mysqli_query($con,$query);
while ($row=mysqli_fetch_array($result))
 {
 $sid=$row['id'];
}
$query="select * from tblroute where name='$d'";
$result=mysqli_query($con,$query);
while ($row=mysqli_fetch_array($result))
 {
 $did=$row['id'];
}
$fare=abs(($did-$sid)* 20);
//echo $fare;
echo '<input  type="text" name="fare" tabindex="2" id="fare" value='$fare'.required autofocus>';
 /*   while($row1 =mysqli_fetch_assoc($result1)) { 
        $opt.="<option value=".$row1['attendance_id']." >".$row1['attendance']."</option>";
  }
    echo $opt;
}*/
?>