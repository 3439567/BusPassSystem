<?php
session_start();
if (!isset($_SESSION['name'])) {
  header('location:student_login.php');
  } 
  $id=$_SESSION["id"];
  $name=$_SESSION['name']; 
  include "../includes/dbconnection.php";
     $sql1="select * from tblreq where idno='$id' and sname='$name'";
    $result1=mysqli_query($dbh,$sql1);
     if (mysqli_num_rows($result1) == 1) {
    while($r=mysqli_fetch_array($result1)){
    $depo_status = $r['depo_status'];
    $clg_status = $r['clg_status'];
    $pay_status = $r['status'];

    if($clg_status=='Pending'){
      echo "<script>alert('College approval required'); window.location.href = 'home.php';</script>";
    }

 else if ($pay_status=='Pending'){
      echo "<script>alert('Payment Not Done'); window.location.href = 'home.php';</script>";
    }

    else if($depo_status=='Pending'){
      echo "<script>alert('Depo approval required'); window.location.href = 'home.php';</script>";
    }
   
  else
  { 
require('fpdf/fpdf.php');
include "phpqrcode/qrlib.php";
$link="http://192.168.1.6/cpp/Bus Pass System/student/view_pass.php?id=".$id."&name=".$name;
QRcode::png($link,$name);
$pdf = new FPDF();
$pdf->AddPage();
$pdf->Image($name,40,10,100,100,"png");
$pdf->Output();
}
}}
else{
   echo "<script>alert('Add Request First'); window.location.href = 'home.php';</script>"; 
}
?>

