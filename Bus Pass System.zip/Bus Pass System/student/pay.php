<?php
session_start();
include "../includes/dbconnection.php";
require('config.php');
require('razorpay-php/Razorpay.php');

// Create the Razorpay Order

use Razorpay\Api\Api;

$api = new Api($keyId, $keySecret);
if(!isset($_SESSION["name"])){
 header("location:student_login.php");
}
 $pid=$_SESSION['id'];
 $name=$_SESSION["name"];

	  $fname=$_POST['name'];
      $idno=$_POST['idno'];
      $cname=$_POST['cname'];
      $source=$_POST['source'];
      $dest=$_POST['dest'];
	  $duration=$_POST['duration'];
	  $cost=$_POST['fare'];
	  $title="BPS";
	  $webtitle="Bus Pass System";
	  $displayCurrency="INR";
	  $imageurl="images/user.png";
	  $_SESSION['cost']=$cost;
	$orderData = [
    'receipt'         => 3456,
    'amount'          => $cost*100, // 2000 rupees in paise
    'currency'        => 'INR',
    'payment_capture' => 1 // auto capture
];
$razorpayOrder = $api->order->create($orderData);

$razorpayOrderId = $razorpayOrder['id'];

$_SESSION['razorpay_order_id'] = $razorpayOrderId;

$displayAmount = $amount = $orderData['amount'];

if ($displayCurrency !== 'INR')
{
    $url = "https://api.fixer.io/latest?symbols=$displayCurrency&base=INR";
    $exchange = json_decode(file_get_contents($url), true);

    $displayAmount = $exchange['rates'][$displayCurrency] * $amount / 100;
}

$data = [
    "key"               => $keyId,
    "amount"            => $amount,
    "name"              => $webtitle,
    "description"       => $title,
    "image"             => $imageurl,
    "prefill"           => [
    "name"              => $fname,
    "email"             => "customer@merchant.com",
    "contact"           => "9999999999",
    ],
    "notes"             => [
    "address"           => "Hello World",
    "merchant_order_id" => "12312321",
    ],
    "theme"             => [
    "color"             => "#F37254"
    ],
    "order_id"          => $razorpayOrderId,
];
if ($displayCurrency !== 'INR')
{
    $data['display_currency']  = $displayCurrency;
    $data['display_amount']    = $displayAmount;
}

$json = json_encode($data);
?>
<html>
<head>
<style>
	.box{
		width: 30%;
		height:30%;
		background-color: gray;
		
	}
</style>
</head>
<body bgcolor="#416A59">
<div id="box" style="background-color:#abd699;width: 30%;height: 40%;
		border-radius: 10px;margin:10% auto;text-align: center;padding: 20px;">
<h3>Name : <?php echo $fname;?></h3>
<h3>Paying To : <?php echo $data['name'];?></h3>
<h3>Amount : <?php echo $orderData['amount']/100;?></h3>

<form action="verify.php" method="POST">
  <script
    src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="<?php echo $data['key']?>"
    data-amount="<?php echo $data['amount']?>"
    data-currency="INR"
    data-name="<?php echo $data['name']?>"
    data-image="<?php echo $data['image']?>"
    data-description="<?php echo $data['description']?>"
    data-prefill.name="<?php echo $data['prefill']['name']?>"
    data-prefill.email="<?php echo $data['prefill']['email']?>"
    data-prefill.contact="<?php echo $data['prefill']['contact']?>"
    data-notes.shopping_order_id="<?php echo $pid;?>"
    data-order_id="<?php echo $data['order_id']?>"
    <?php if ($displayCurrency !== 'INR') { ?> data-display_amount="<?php echo $data['display_amount']?>" <?php } ?>
    <?php if ($displayCurrency !== 'INR') { ?> data-display_currency="<?php echo $data['display_currency']?>" <?php } ?>
  >
  </script>
  <!-- Any extra fields to be submitted with the form but not sent to Razorpay -->
  <input type="hidden" name="shopping_order_id" value="<?php echo $pid;?>">
</form>
</div>
</body>
</html>