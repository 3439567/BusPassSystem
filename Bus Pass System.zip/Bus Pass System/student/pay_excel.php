<?php
session_start();
include "../includes/dbconnection.php";
if(!isset($_SESSION["name"])){
 header("location:student_login.php");
}
 $id=$_SESSION['id'];
 $name=$_SESSION["name"];
 
 $sql="SELECT * FROM tblpayment WHERE stu_id='$id' and pay_name='$name'";
     $result = mysqli_query($dbh, $sql);
	 $html='<table><tr>
	 <td>Pay Id</td>
	 <td>Amount</td>
	 <td>Date</td>
	 </tr>
	 ';
     while($row=mysqli_fetch_array($result)){
		  
		$html.='<tr><td>'.$row['pay_id'].'</td><td>'.$row['pay_name'].'</td><td>'.$row['amount'].'</td><td>'.
                $row['date_of_pay'].'<td></tr>';		
               }
	    $html.='</table>';
		header("Content-Type:application/xls");
		header("Content-Disposition:attachment;filename=payment_history.xls");
		echo $html;
?>