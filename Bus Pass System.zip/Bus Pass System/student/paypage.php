<?php
session_start();
include "../includes/dbconnection.php";
require('../config.php');
require('razorpay-php/Razorpay.php');

// Create the Razorpay Order

use Razorpay\Api\Api;

$api = new Api($keyId, $keySecret);
if(!isset($_SESSION["name"])){
 header("location:student_login.php");
}
 $id=$_SESSION['id'];
 $name=$_SESSION["name"];

$sql1="select * from tblreq where idno='$id' and sname='$name'";
    $result1=mysqli_query($dbh,$sql1);
     if (mysqli_num_rows($result1) == 1) {
 $sql="SELECT * FROM tblpass WHERE IdentityCardno='$id' and FullName='$name'";
     $result = mysqli_query($dbh, $sql);
    while($row=mysqli_fetch_array($result)){
      $passno=$row['PassNumber'];
      
    }
if($passno=='')
{
    echo "<script>alert('Redirecting to Payment Page'); window.location.href = 'razorpay-php-testapp-master/pay.php';</script>";
}
else{
   echo "<script>alert('Redirecting to Payment Page'); window.location.href = 'razorpay-php-testapp-master/pay.php';</script>"; 
}
}
else{
	
   echo "<script>alert('Add Request First'); window.location.href = 'home.php';</script>"; 
 
}

?>
