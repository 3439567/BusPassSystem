<?php
 include '../includes/dbconnection.php';

 if(isset($_POST['submit'])){
	$clgid = $_POST['clgid'];
	$passid = $_POST['passid'];
	$source = $_POST['from'];
	$dest = $_POST['to'];
	$email= $_POST['email'];
	$mob=$_POST['mobile'];
	$route=$_POST['route'];
	$name=$_POST['name'];
	echo $clgid;
date_default_timezone_set("Asia/Kolkata");
$today=date("Y-m-d");
$sql="select * from tbljourney where id='$passid'";
$result=mysqli_query($dbh,$sql);
while($row=mysqli_fetch_array($result)){
	$ro=$row['route'];
	$date=$row['date'];
}
if($ro==$route && $date==$today){
	echo "<script>alert('Already Punched'); window.location.href = 'view_pass.php';</script>";
}
else{

	$sql="insert into tbljourney (id,name,route,date) values 
	('$passid','$name','$route','$today')";
	
	if(mysqli_query($dbh,$sql)){
		 echo "<script>alert('Pass Punched Successfully'); window.location.href = 'home.php';</script>";
	
	}
	else{
		echo "<script>alert('Failed'); window.location.href = 'view_pass.php';</script>";
	}
}
}
?>