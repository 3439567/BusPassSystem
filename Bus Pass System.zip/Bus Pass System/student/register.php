<html>

<head>
  <link rel="stylesheet" href="css/style.css">
  <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
  <title>Register</title>
  <style>
   body {
        background-color: #F3EBF6;
        font-family: 'Ubuntu', sans-serif;
    }
    
    .main {
        background-color: #FFFFFF;
        width: 600px;
        height: 740px;
        margin: 7em auto;
        border-radius: 1.5em;
        box-shadow: 0px 11px 35px 2px rgba(0, 0, 0, 0.14);
    }
    
    .sign {
        padding-top: 40px;
        color: #8C55AA;
        font-family: 'Ubuntu', sans-serif;
        font-weight: bold;
        font-size: 23px;
    }
    
    .un {
    width: 76%;
    color: rgb(38, 50, 56);
    font-weight: 700;
    font-size: 14px;
    letter-spacing: 1px;
    background: rgba(136, 126, 126, 0.04);
    padding: 10px 20px;
    border: none;
    border-radius: 20px;
    outline: none;
    box-sizing: border-box;
    border: 2px solid rgba(0, 0, 0, 0.02);
    margin-bottom: 50px;
    margin-left: 46px;
    text-align: center;
    margin-bottom: 27px;
    font-family: 'Ubuntu', sans-serif;
    }
    
    form.form1 {
        padding-top: 40px;
    }
    
    .pass {
            width: 76%;
    color: rgb(38, 50, 56);
    font-weight: 700;
    font-size: 14px;
    letter-spacing: 1px;
    background: rgba(136, 126, 126, 0.04);
    padding: 10px 20px;
    border: none;
    border-radius: 20px;
    outline: none;
    box-sizing: border-box;
    border: 2px solid rgba(0, 0, 0, 0.02);
    margin-bottom: 50px;
    margin-left: 46px;
    text-align: center;
    margin-bottom: 27px;
    font-family: 'Ubuntu', sans-serif;
    }
    
   
    .un:focus, .pass:focus {
        border: 2px solid rgba(0, 0, 0, 0.18) !important;
        
    }
    
    .submit {
      cursor: pointer;
        border-radius: 5em;
        color: #fff;
        background: linear-gradient(to right, #9C27B0, #E040FB);
        border: 0;
        padding-left: 40px;
        padding-right: 40px;
        padding-bottom: 10px;
        padding-top: 10px;
        font-family: 'Ubuntu', sans-serif;
        margin-left: 35%;
        font-size: 13px;
        box-shadow: 0 0 20px 1px rgba(0, 0, 0, 0.04);
    }
    
  
    
    @media (max-width: 600px) {
        .main {
            border-radius: 0px;
        }
        
        

  
  
  
  </style>
</head>

<body>
  <div class="main">
    <p class="sign" align="center">Register Here</p>
    <form class="form1" method="post" enctype="multipart/form-data">
	  <input class="un " type="text" align="center" placeholder="enter name" name="name">
	   <input class="un " type="mobile" align="center" placeholder="enter mobile no" name="mob">
	  <input class="un " type="email" align="center" placeholder="email" name="email">
	  <input class="un" type="text" align="center" placeholder="password" name="pass">
      <input class="un" type="text" align="center" placeholder="id number" name="cid">
       <input class="un" type="text" align="center" placeholder="college name" name="cname">

     <!--   <select name="source" class="un">
       <option>Select Source</option>
        <option value="Kankavli">Kankavli</option>
       <option value="Osargaon">Osargaon</option>
       <option value="Kasal">Kasal</option>
        <option value="Sukalwad">Sukalwad</option>
     </select>

<select name="dest" class="un">
       <option>Select Deestination</option>
       <option value="Kankavli">Kankavli</option>
       <option value="Osargaon">Osargaon</option>
       <option value="Kasal">Kasal</option>
        <option value="Sukalwad">Sukalwad</option>
     </select>-->
        <input class="un " type="file" align="center" placeholder="profie photo" name="pic">
      <input type="submit" class="submit" align="center" name="submit" value="Register">
         
    </div>
     
</body>

</html>
<?php
include "../includes/dbconnection.php";
if(isset($_POST['submit'])){
	$name = $_POST['name'];
	$mob = $_POST['mob'];
	$email = $_POST['email'];
	$cid = $_POST['cid'];
    $cname = $_POST['cname'];
    $pass=$_POST['pass'];
    //$source = $_POST['source'];
   // $dest = $_POST['dest'];
    $file=$_FILES['pic']['tmp_name'];
    $image = $_FILES["pic"] ["name"];
    $image_name= addslashes($_FILES['pic']['name']);
    $size = $_FILES["pic"] ["size"];
    $error = $_FILES["pic"] ["error"];
    move_uploaded_file($_FILES["pic"]["tmp_name"],"upload/" . $_FILES["pic"]["name"]);          
    $location="upload/" . $_FILES["pic"]["name"];
  

	
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	
	$sql="insert into tblpass (FullName,ProfileImage,ContactNumber,Email,IdentityCardno,college,password) values 
	('$name','$location','$mob','$email','$cid','$cname','$pass')";
	
	if(mysqli_query($dbh,$sql)){
		 echo "<script>alert('Registration Done'); window.location.href = 'student_login.php';</script>";
	
	}
	else{
		?>	
		<script>alert("Registration failed");
		</script>
		<?php
		 
	   }


	
	mysqli_close($con);
}
?>